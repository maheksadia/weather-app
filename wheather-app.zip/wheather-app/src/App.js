import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

import Header from './components/Header';
import SearchBar from './components/SearchBar';
import WeatherInfo from './components/WeatherInfo';
import ErrorMessage from './components/ErrorMessage';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');

  const API_KEY = '5d69bda50646d187c8f8ffbe8e697fe3'; // Replace with your OpenWeatherMap API key

  const fetchWeather = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      );
      setWeather(response.data);
    } catch (err) {
      setWeather(null);
      setError('City not found!');
    }
  };

  return (
    <div className="app">
      <Header />
      <SearchBar city={city} setCity={setCity} fetchWeather={fetchWeather} />
      {error && <ErrorMessage error={error} />}
      {weather && <WeatherInfo weather={weather} />}
    </div>
  );
}

export default App;
