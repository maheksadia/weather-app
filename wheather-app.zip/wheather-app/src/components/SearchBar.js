import React from 'react';

function SearchBar({ city, setCity, fetchWeather }) {
  return (
    <form onSubmit={fetchWeather}>
      <input
        type="text"
        placeholder="Enter city"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button type="submit">Get Weather</button>
    </form>
  );
}

export default SearchBar;
